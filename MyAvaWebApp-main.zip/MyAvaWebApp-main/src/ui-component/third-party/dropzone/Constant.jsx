export const DropzoneType = {
    default: 'DEFAULT',
    standard: 'STANDARD'
};
