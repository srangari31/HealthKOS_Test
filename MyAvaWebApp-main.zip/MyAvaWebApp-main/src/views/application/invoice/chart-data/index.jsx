// chart data
import InvoiceChartCardData1 from './invoice-chart-1';
import InvoiceChartCardData2 from './invoice-chart-2';
import InvoiceChartCardData3 from './invoice-chart-3';
import InvoiceChartCardData4 from './invoice-chart-4';

// ==============================|| WIDGET - CHART DATA OBJECT ||============================== //

const chartData = {
    InvoiceChartCardData1,
    InvoiceChartCardData2,
    InvoiceChartCardData3,
    InvoiceChartCardData4
};

export default chartData;
