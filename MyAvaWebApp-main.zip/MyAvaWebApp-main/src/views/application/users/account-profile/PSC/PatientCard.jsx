import React from 'react';
import { Card, CardContent, Typography, Grid, Avatar, IconButton, Box, Tooltip } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import EditNoteRoundedIcon from '@mui/icons-material/EditNoteRounded';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';

import BloodPressureIcon from 'src/assets/images/patients/blood-pressure.png';
import HeartRateIcon from 'src/assets/images/patients/cardiogram.png';
import WeightIcon from 'src/assets/images/patients/weight.png';
import SpO2Icon from 'src/assets/images/patients/blood.png';
import HeightIcon from 'src/assets/images/patients/height.png';
import HbA1cIcon from 'src/assets/images/patients/sugar.png';
import BMIIcon from 'src/assets/images/patients/bmi.png';
import ActivityIcon from 'src/assets/images/patients/exercise.png';
import { ThemeMode } from 'config';
import useConfig from 'src/hooks/useConfig';

const formatLastUpdated = (minutes) => {
    if (minutes < 60) {
        return `Last Updated: ${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
    } else if (minutes < 1440) {
        const hours = Math.floor(minutes / 60);
        return `Last Updated: ${hours} hour${hours !== 1 ? 's' : ''} ago`;
    } else {
        const days = Math.floor(minutes / 1440);
        return `Last Updated: ${days} day${days !== 1 ? 's' : ''} ago`;
    }
};

const PatientCard = ({ patient }) => {
    const theme = useTheme();
    const { mode } = useConfig();

    return (
        <Box
            sx={{
                position: 'relative',
                width: '100%',
                borderRadius: 5,
                bgcolor: mode === ThemeMode.DARK ? 'dark.main' : 'primary.light',
                padding: '0px'
            }}
        >
            <Card
                sx={{
                    bgcolor: theme.palette.mode === ThemeMode.DARK ? 'dark.main' : 'grey.50',
                    borderRadius: 5,
                    padding: '5px',
                    position: 'relative',
                    border: '1px solid',
                    boxShadow: 0.5,
                    borderColor: theme.palette.mode === ThemeMode.DARK ? 'primary.light' : 'grey.600',
                    transition: '0.3s',
                    '&:hover': { boxShadow: 4 }
                }}
            >
                <Tooltip title="Bookmark" placement="top">
                    <IconButton aria-label="bookmark" size="small" sx={{ position: 'absolute', top: 4, left: 7 }}>
                        <BookmarkBorderIcon />
                    </IconButton>
                </Tooltip>
                <Tooltip title="Edit" placement="top">
                    <IconButton aria-label="edit" size="small" sx={{ position: 'absolute', top: 4, right: 7 }}>
                        <EditNoteRoundedIcon />
                    </IconButton>
                </Tooltip>
                <CardContent sx={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'nowrap', paddingBottom: '2px' }}>
                    <Avatar sx={{ width: 50, height: 50, background: '#21AAF3', color: '#FFFFFF' }}>
                        <Typography variant="h4" color="white">
                            {patient.firstName.charAt(0)}
                            {patient.lastName.charAt(0)}
                        </Typography>
                    </Avatar>
                    <Box sx={{ minWidth: '150px', flexShrink: 0 }}>
                        <Typography variant="subtitle1" noWrap>
                            {patient.fullName} ({patient.age}/{patient.gender.charAt(0)})
                        </Typography>
                        <Typography variant="caption" color="textSecondary">
                            ID: {patient.patientId}
                        </Typography>
                    </Box>
                    <Grid container spacing={1} alignItems="center" sx={{ flexGrow: 1, flexWrap: 'nowrap' }}>
                        {[
                            { src: BloodPressureIcon, label: 'BP', value: patient.bp },
                            { src: HeartRateIcon, label: 'Pulse', value: patient.pulse },
                            { src: WeightIcon, label: 'Weight', value: `${patient.weight} kg` },
                            { src: SpO2Icon, label: 'SpO2', value: patient.spO2 },
                            { src: HeightIcon, label: 'Height', value: `${patient.height} cm` },
                            { src: HbA1cIcon, label: 'HbA1c', value: patient.hbA1c },
                            { src: BMIIcon, label: 'BMI', value: '--' },
                            { src: ActivityIcon, label: 'Activity', value: patient.activity }
                        ].map((item, index) => (
                            <Grid key={index} item sx={{ textAlign: 'center' }}>
                                <Tooltip title={item.label} placement="top">
                                    <img
                                        src={item.src}
                                        alt={item.label}
                                        style={{
                                            width: 18,
                                            height: 18
                                        }}
                                    />
                                </Tooltip>
                                <Typography variant="caption" display="block">
                                    {item.value}
                                </Typography>
                            </Grid>
                        ))}
                    </Grid>
                    <Box
                        sx={{
                            bgcolor: theme.palette.mode === ThemeMode.DARK ? 'dark.main' : 'primary.light',
                            padding: '6px',
                            borderRadius: '6px',
                            border: '1px solid #d1d3e2',
                            minWidth: '320px',
                            flexShrink: 0
                        }}
                    >
                        <Typography variant="body2" fontWeight="bold">
                            <Typography variant="caption" color="textSecondary">
                                Last Notes: {patient.latestNotes}
                            </Typography>{' '}
                            Spoke to patient
                        </Typography>

                        <Box sx={{ display: 'flex', justifyContent: 'space-between', marginTop: '4px' }}>
                            <Typography variant="caption" color="error">
                                {formatLastUpdated(patient.lastUpdatedInMinute)}
                            </Typography>
                            <Typography variant="caption" color="textSecondary">
                                00:01:19
                            </Typography>
                        </Box>
                    </Box>
                </CardContent>
            </Card>
        </Box>
    );
};

export default PatientCard;
